import { Outlet } from 'react-router-dom';
import BottomNav from '../BottomNav';

// 하단 탭바가 필요한 화면(홈/콘텐츠/프로필)을 감싸는 레이아웃.
// 얼굴인식·호흡모니터링·피드백·업로드 같은 단독 플로우 화면은 이 레이아웃 밖에 둔다.
const MainLayout: React.FC = () => {
  return (
    <>
      <Outlet />
      <BottomNav />
    </>
  );
};

export default MainLayout;
