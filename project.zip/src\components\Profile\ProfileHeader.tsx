import { User } from 'lucide-react';

interface ProfileHeaderProps {
  nickname: string;
  followers: number;
  following: number;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ nickname, followers, following }) => {
  return (
    <div className="px-5 pt-6">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-12 h-12 rounded-full bg-white border border-gray-100 flex items-center justify-center text-[#72E0BF]">
          <User size={20} strokeWidth={1.8} />
        </div>
        <p className="text-lg font-bold text-[#1A4D43]">{nickname}</p>
      </div>

      <div className="flex gap-2.5">
        <div className="flex-1 bg-white border border-gray-100 rounded-2xl p-3.5">
          <p className="text-lg font-bold text-[#1A4D43]">{followers}</p>
          <p className="text-xs text-gray-400">팔로워</p>
        </div>
        <div className="flex-1 bg-white border border-gray-100 rounded-2xl p-3.5">
          <p className="text-lg font-bold text-[#1A4D43]">{following}</p>
          <p className="text-xs text-gray-400">팔로잉</p>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;
