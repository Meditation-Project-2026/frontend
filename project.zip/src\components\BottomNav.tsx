import { NavLink } from 'react-router-dom';
import { Home, Leaf, PlusCircle, User } from 'lucide-react';

interface NavItem {
  to: string;
  label: string;
  Icon: typeof Home;
  end?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { to: '/', label: '홈', Icon: Home, end: true },
  { to: '/contents', label: '콘텐츠', Icon: Leaf },
  { to: '/upload', label: '업로드', Icon: PlusCircle },
  { to: '/profile', label: '프로필', Icon: User },
];

const BottomNav: React.FC = () => {
  return (
    <nav
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md
                 bg-background-serene border-t border-gray-100
                 flex items-stretch px-2 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))]
                 z-40"
    >
      {NAV_ITEMS.map(({ to, label, Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) =>
            `flex-1 flex flex-col items-center gap-1 py-1 text-[11px] font-semibold transition-colors ${
              isActive ? 'text-[#72E0BF]' : 'text-gray-400'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <Icon size={19} strokeWidth={isActive ? 2.2 : 1.8} />
              <span>{label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
};

export default BottomNav;
